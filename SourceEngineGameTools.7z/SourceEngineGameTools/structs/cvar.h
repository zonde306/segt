#pragma once
class Convar
{
public:

};
class CCvar
{
public:
	
};